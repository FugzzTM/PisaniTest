package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private TextView textViewHello;
    private EditText editText;
    private TextView gotoviTekst;

    private TextView clickButtonSlika;

    private TextView clickButtonFoto;

    private ImageView slikaSlika;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewHello = findViewById(R.id.textViewHello);
        editText = findViewById(R.id.editTekst);
        gotoviTekst = findViewById(R.id.gotoviTekst);
        clickButtonSlika = findViewById(R.id.clickButtonSlika);
        clickButtonFoto = findViewById(R.id.clickButtonFoto);
        slikaSlika =findViewById(R.id.slikaSlika);
    }

    public void clickPromjenaGumb(View view){
        String text ="";
        text = editText.getText().toString();
        gotoviTekst.setText(text);
    }
    public void clickButtonPromjenaSJ(View view){
        slikaSlika.setImageResource(R.drawable.redapple);
    }
    public void clickButtonPromjenaSD(View view){
        slikaSlika.setImageResource(R.drawable.pear);
    }
}
